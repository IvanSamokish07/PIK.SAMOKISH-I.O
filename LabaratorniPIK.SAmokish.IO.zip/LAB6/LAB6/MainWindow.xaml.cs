﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lab6_Styles
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ChangeThemeButton_Click(object sender, RoutedEventArgs e)
        {
            // Додаткова логіка при кліку (наприклад, показ повідомлення)
            MessageBox.Show("Тема змінена! Стиль застосовано динамічно.", "Успіх");
            // Тут можна додати зміну глобальних ресурсів для всієї теми, але для варіанту достатньо тригерів
        }
    }
}