﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace UserCardsSample
{
    public class MainViewModel
    {
        public ObservableCollection<User> Users { get; } = new ObservableCollection<User>
        {
            new User { Name = "Іван Самокіш", Age = 21 },
            new User { Name = "Олена Коваль", Age = 19 },
            new User { Name = "Петро Мельник", Age = 25 }
        };
    }
}
