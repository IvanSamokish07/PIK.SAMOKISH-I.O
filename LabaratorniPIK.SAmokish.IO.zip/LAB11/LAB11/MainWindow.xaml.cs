﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lab11Variant22
{
    public partial class MainWindow : Window
    {
        // Приклад даних: словник категорій та їх товарів
        private Dictionary<string, List<string>> categoriesProducts = new Dictionary<string, List<string>>
        {
            { "Електроніка", new List<string> { "Смартфон", "Ноутбук", "Навушники" } },
            { "Одяг", new List<string> { "Футболка", "Джинси", "Куртка" } },
            { "Книги", new List<string> { "Роман", "Підручник", "Комікс" } }
        };

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Category_Checked(object sender, RoutedEventArgs e)
        {
            UpdateProductsList();
        }

        private void Category_Unchecked(object sender, RoutedEventArgs e)
        {
            UpdateProductsList();
        }

        private void UpdateProductsList()
        {
            // Перевіряємо, чи всі чекбокси вибрані
            bool allSelected = CategoryElectronics.IsChecked == true &&
                               CategoryClothing.IsChecked == true &&
                               CategoryBooks.IsChecked == true;

            ProductsListBox.Items.Clear();

            if (allSelected)
            {
                // Якщо всі вибрані, додаємо товари з усіх категорій
                foreach (var category in categoriesProducts.Values)
                {
                    foreach (var product in category)
                    {
                        ProductsListBox.Items.Add(product);
                    }
                }
            }
        }
    }
}