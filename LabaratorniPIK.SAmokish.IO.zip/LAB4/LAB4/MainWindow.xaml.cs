﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MobileLoginApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text;
            string password = PasswordBox.Password;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Будь ласка, введіть email/телефон та пароль.", "Помилка авторизації", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Проста перевірка (замініть на реальну логіку, наприклад, API)
            if (username == "user" && password == "password")
            {
                MessageBox.Show("Авторизація успішна! Вітаємо в додатку.", "Успіх", MessageBoxButton.OK, MessageBoxImage.Information);
                // Тут можна додати перехід до головного екрану
            }
            else
            {
                MessageBox.Show("Неправильний email/телефон або пароль.", "Помилка авторизації", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RegisterLink_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            MessageBox.Show("Перехід до реєстрації... (імітація для прототипу)", "Реєстрація");
            // Тут можна відкрити нове вікно для реєстрації
        }

        private void PasswordBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            // Оновлення видимості плейсхолдера для PasswordBox
            if (string.IsNullOrEmpty(PasswordBox.Password))
            {
                // Логіка для показу/приховування плейсхолдера не працює напряму через байндинг,
                // тому ми не можемо оновити TextBlock автоматично. Потрібно вручну.
                // Це обмеження WPF для PasswordBox.
            }
        }
    }
}