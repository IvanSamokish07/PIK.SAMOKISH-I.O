﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace Lab12Variant22
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        // Обробник для початку перетягування з ListBox
        private void FileListBox_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                // Отримуємо вибраний елемент (шлях до файлу)
                if (FileListBox.SelectedItem is string selectedFile && File.Exists(selectedFile))
                {
                    // Починаємо перетягування
                    DragDrop.DoDragDrop(FileListBox, selectedFile, DragDropEffects.Copy);
                }
            }
        }

        // Обробник для Drop у TextBox (відображаємо вміст файлу)
        private void ContentTextBox_Drop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.Text))
            {
                string filePath = (string)e.Data.GetData(DataFormats.Text);
                if (File.Exists(filePath))
                {
                    try
                    {
                        // Читаємо вміст файлу (припускаємо текстовий файл)
                        string content = File.ReadAllText(filePath);
                        ContentTextBox.Text = content;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Помилка читання файлу: {ex.Message}");
                    }
                }
            }
        }

        // Додатково: Обробник для Drop у ListBox (щоб додавати файли ззовні)
        private void FileListBox_Drop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
                foreach (string file in files)
                {
                    FileListBox.Items.Add(file);
                }
            }
        }
    }
}