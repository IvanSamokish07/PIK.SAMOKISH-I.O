﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Animation;

namespace Lab10Variant22
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // Створюємо анімацію для зміни кольору фону
            ColorAnimation colorAnimation = new ColorAnimation
            {
                From = Colors.Black,    // Початковий колір: темрява
                To = Colors.White,      // Кінцевий колір: світло
                Duration = TimeSpan.FromSeconds(2),  // Тривалість анімації
                AutoReverse = false,    // Не повертатися назад
                RepeatBehavior = RepeatBehavior.Forever  // Повторювати безкінечно
            };

            // Прив'язуємо анімацію до фону Grid
            SolidColorBrush brush = new SolidColorBrush(Colors.Black);
            MainGrid.Background = brush;
            brush.BeginAnimation(SolidColorBrush.ColorProperty, colorAnimation);
        }
    }
}