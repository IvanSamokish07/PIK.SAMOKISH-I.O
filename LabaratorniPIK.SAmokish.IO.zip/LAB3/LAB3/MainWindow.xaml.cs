﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Windows.Threading;

namespace CustomListBoxLab
{
    public class Item
    {
        public string Name { get; set; }
        public bool IsHighlighted { get; set; } = false;
    }

    public partial class MainWindow : Window
    {
        private ObservableCollection<Item> items = new ObservableCollection<Item>();

        public MainWindow()
        {
            InitializeComponent();

            // Додаємо щонайменше 15 унікальних елементів
            for (int i = 1; i <= 15; i++)
            {
                items.Add(new Item { Name = $"Елемент {i}" });
            }

            myListBox.ItemsSource = items;
        }

        private void Up_Click(object sender, RoutedEventArgs e)
        {
            if (myListBox.SelectedItem is Item selected)
            {
                int index = items.IndexOf(selected);
                if (index > 0)
                {
                    items.Move(index, index - 1);
                    Highlight(selected);
                }
            }
        }

        private void Down_Click(object sender, RoutedEventArgs e)
        {
            if (myListBox.SelectedItem is Item selected)
            {
                int index = items.IndexOf(selected);
                if (index < items.Count - 1)
                {
                    items.Move(index, index + 1);
                    Highlight(selected);
                }
            }
        }

        private void Highlight(Item item)
        {
            item.IsHighlighted = true;
            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            timer.Tick += (s, args) =>
            {
                item.IsHighlighted = false;
                timer.Stop();
            };
            timer.Start();
        }
    }
}