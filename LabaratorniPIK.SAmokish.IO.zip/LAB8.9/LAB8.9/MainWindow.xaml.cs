﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Animation;

namespace SplitEffectDemo
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void StartSplit_Click(object sender, RoutedEventArgs e)
        {
            var sb = (Storyboard)this.Resources["SplitStoryboard"];
            // Якщо бажаєте зупиняти і починати заново:
            sb.Stop(this);
            sb.Begin(this, true); // controllable = true
        }

        private void Reset_Click(object sender, RoutedEventArgs e)
        {
            // Отримати storyboard з ресурсів
            var sb = (Storyboard)this.Resources["SplitStoryboard"];
            if (sb != null)
            {
                // Зупинити і видалити анімацію з вікна — після Remove базові значення застосовуються
                sb.Stop(this);
                sb.Remove(this);
            }

            // Тепер без проблем скидаємо трансформації/опротність
            LeftTransform.X = 0;
            RightTransform.X = 0;
            LeftRotate.Angle = 0;
            RightRotate.Angle = 0;
            LeftPart.Opacity = 1;
            RightPart.Opacity = 1;
        }
    }
}
