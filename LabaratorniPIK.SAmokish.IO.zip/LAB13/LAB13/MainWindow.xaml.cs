﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.Collections.ObjectModel;
using System.Windows.Media.Animation;

namespace ImageViewerApp
{
    public partial class MainWindow : Window
    {
        private ObservableCollection<Uri> history = new ObservableCollection<Uri>();
        private bool isAnimationRunning = false;

        public MainWindow()
        {
            InitializeComponent();
            historyListBox.ItemsSource = history;
        }

        // Обробник для завантаження нового зображення
        private void LoadImageButton_Click(object sender, RoutedEventArgs e)
        {
            if (isAnimationRunning) return; // Уникаємо накладання анімацій

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Зображення (*.jpg;*.png;*.bmp)|*.jpg;*.png;*.bmp";
            if (openFileDialog.ShowDialog() == true)
            {
                Uri imageUri = new Uri(openFileDialog.FileName);
                DisplayImageWithAnimation(imageUri);
                if (!history.Contains(imageUri))
                {
                    history.Add(imageUri);
                }
            }
        }

        // Обробник для вибору зображення зі списку історії
        private void HistoryListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (isAnimationRunning || historyListBox.SelectedItem == null) return;

            if (historyListBox.SelectedItem is Uri selectedUri)
            {
                DisplayImageWithAnimation(selectedUri);
            }
        }

        // Метод для відображення зображення з анімацією (fade-in)
        private void DisplayImageWithAnimation(Uri imageUri)
        {
            try
            {
                isAnimationRunning = true;
                BitmapImage bitmap = new BitmapImage(imageUri);
                mainImage.Source = bitmap;
                mainImage.Opacity = 0; // Початкова прозорість

                DoubleAnimation fadeIn = new DoubleAnimation
                {
                    From = 0.0,
                    To = 1.0,
                    Duration = new Duration(TimeSpan.FromSeconds(0.5)),
                    FillBehavior = FillBehavior.Stop // Завершення анімації після виконання
                };

                fadeIn.Completed += (s, e) => isAnimationRunning = false; // Скидання прапора після завершення
                mainImage.BeginAnimation(Image.OpacityProperty, fadeIn);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Помилка завантаження зображення: " + ex.Message);
                isAnimationRunning = false;
            }
        }
    }
}